<?php
// GENERATED CODE -- DO NOT EDIT!

namespace nazk\logs\v2;

/**
 * SERVICES
 */
class RuleServiceClient extends \Grpc\BaseStub {

    /**
     * @param string $hostname hostname
     * @param array $opts channel options
     * @param \Grpc\Channel $channel (optional) re-use channel object
     */
    public function __construct($hostname, $opts, $channel = null) {
        parent::__construct($hostname, $opts, $channel);
    }

    /**
     * @param \nazk\logs\v2\CreateRuleRequest $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function CreateRule(\nazk\logs\v2\CreateRuleRequest $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/v2.RuleService/CreateRule',
        $argument,
        ['\nazk\logs\v2\CreateRuleResponse', 'decode'],
        $metadata, $options);
    }

    /**
     * @param \nazk\logs\v2\FindRulesRequest $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function FindRules(\nazk\logs\v2\FindRulesRequest $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/v2.RuleService/FindRules',
        $argument,
        ['\nazk\logs\v2\FindRulesResponse', 'decode'],
        $metadata, $options);
    }

}
