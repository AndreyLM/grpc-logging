<?php
// GENERATED CODE -- DO NOT EDIT!

namespace nazk\logs\v2;

/**
 * ALL IN ONE SERVICE
 */
class LogginServiceClient extends \Grpc\BaseStub {

    /**
     * @param string $hostname hostname
     * @param array $opts channel options
     * @param \Grpc\Channel $channel (optional) re-use channel object
     */
    public function __construct($hostname, $opts, $channel = null) {
        parent::__construct($hostname, $opts, $channel);
    }

    /**
     * @param \nazk\logs\v2\CreateUserRequest $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function CreateUser(\nazk\logs\v2\CreateUserRequest $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/v2.LogginService/CreateUser',
        $argument,
        ['\nazk\logs\v2\CreateUserResponse', 'decode'],
        $metadata, $options);
    }

    /**
     * @param \nazk\logs\v2\FindUsersRequest $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function FindUsers(\nazk\logs\v2\FindUsersRequest $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/v2.LogginService/FindUsers',
        $argument,
        ['\nazk\logs\v2\FindUsersResponse', 'decode'],
        $metadata, $options);
    }

    /**
     * @param \nazk\logs\v2\CreateRuleRequest $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function CreateRule(\nazk\logs\v2\CreateRuleRequest $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/v2.LogginService/CreateRule',
        $argument,
        ['\nazk\logs\v2\CreateRuleResponse', 'decode'],
        $metadata, $options);
    }

    /**
     * @param \nazk\logs\v2\FindRulesRequest $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function FindRules(\nazk\logs\v2\FindRulesRequest $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/v2.LogginService/FindRules',
        $argument,
        ['\nazk\logs\v2\FindRulesResponse', 'decode'],
        $metadata, $options);
    }

    /**
     * @param \nazk\logs\v2\CreateExchangeRequest $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function CreateExchange(\nazk\logs\v2\CreateExchangeRequest $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/v2.LogginService/CreateExchange',
        $argument,
        ['\nazk\logs\v2\CreateExchangeResponse', 'decode'],
        $metadata, $options);
    }

    /**
     * @param \nazk\logs\v2\FindExchangesRequest $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function FindExchanges(\nazk\logs\v2\FindExchangesRequest $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/v2.LogginService/FindExchanges',
        $argument,
        ['\nazk\logs\v2\FindExchangesResponse', 'decode'],
        $metadata, $options);
    }

    /**
     * @param \nazk\logs\v2\CreateDeclarationRequest $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function CreateDeclaration(\nazk\logs\v2\CreateDeclarationRequest $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/v2.LogginService/CreateDeclaration',
        $argument,
        ['\nazk\logs\v2\CreateDeclarationResponse', 'decode'],
        $metadata, $options);
    }

    /**
     * @param \nazk\logs\v2\FindDeclarationsRequest $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function FindDeclarations(\nazk\logs\v2\FindDeclarationsRequest $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/v2.LogginService/FindDeclarations',
        $argument,
        ['\nazk\logs\v2\FindDeclarationsResponse', 'decode'],
        $metadata, $options);
    }

}
