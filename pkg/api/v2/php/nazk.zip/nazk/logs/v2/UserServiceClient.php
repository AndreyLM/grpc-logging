<?php
// GENERATED CODE -- DO NOT EDIT!

namespace nazk\logs\v2;

/**
 * SERVICES
 */
class UserServiceClient extends \Grpc\BaseStub {

    /**
     * @param string $hostname hostname
     * @param array $opts channel options
     * @param \Grpc\Channel $channel (optional) re-use channel object
     */
    public function __construct($hostname, $opts, $channel = null) {
        parent::__construct($hostname, $opts, $channel);
    }

    /**
     * @param \nazk\logs\v2\CreateUserRequest $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function CreateUser(\nazk\logs\v2\CreateUserRequest $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/v2.UserService/CreateUser',
        $argument,
        ['\nazk\logs\v2\CreateUserResponse', 'decode'],
        $metadata, $options);
    }

    /**
     * @param \nazk\logs\v2\FindUsersRequest $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function FindUsers(\nazk\logs\v2\FindUsersRequest $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/v2.UserService/FindUsers',
        $argument,
        ['\nazk\logs\v2\FindUsersResponse', 'decode'],
        $metadata, $options);
    }

}
