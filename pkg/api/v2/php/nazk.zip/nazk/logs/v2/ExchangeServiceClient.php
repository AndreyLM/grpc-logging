<?php
// GENERATED CODE -- DO NOT EDIT!

namespace nazk\logs\v2;

/**
 * SERVICES
 */
class ExchangeServiceClient extends \Grpc\BaseStub {

    /**
     * @param string $hostname hostname
     * @param array $opts channel options
     * @param \Grpc\Channel $channel (optional) re-use channel object
     */
    public function __construct($hostname, $opts, $channel = null) {
        parent::__construct($hostname, $opts, $channel);
    }

    /**
     * @param \nazk\logs\v2\CreateExchangeRequest $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function CreateExchange(\nazk\logs\v2\CreateExchangeRequest $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/v2.ExchangeService/CreateExchange',
        $argument,
        ['\nazk\logs\v2\CreateExchangeResponse', 'decode'],
        $metadata, $options);
    }

    /**
     * @param \nazk\logs\v2\FindExchangesRequest $argument input argument
     * @param array $metadata metadata
     * @param array $options call options
     */
    public function FindExchanges(\nazk\logs\v2\FindExchangesRequest $argument,
      $metadata = [], $options = []) {
        return $this->_simpleRequest('/v2.ExchangeService/FindExchanges',
        $argument,
        ['\nazk\logs\v2\FindExchangesResponse', 'decode'],
        $metadata, $options);
    }

}
